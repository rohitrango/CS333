#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>

#include "make-tokens.h"
#include "utils.h"

#define CWD_LEN 1024
#define STDOUT 1

int main(int argc, char const *argv[])
{
	char cmd[MAX_INPUT_SIZE];
	char path[CWD_LEN];

	while(1) {

		// get current path, uncomment the first one
		bzero(path, CWD_LEN);
		getcwd(path, CWD_LEN);
		// printf("mosh:%s> ", path);
		printf("mosh> ");

		/* make cmd blank and take input */
		bzero(cmd, MAX_INPUT_SIZE);
        gets(cmd);
        cmd[strlen(cmd)] = '\n';  		
        
        /* get tokens and tokenCount */
		char **tokens = tokenize(cmd);
		int tokenCount = 0;
		for(tokenCount=0;tokens[tokenCount]!=NULL; tokenCount++);

		// variables for redirection
		int redirectIndex;
		char **firstCommand, *mFile;

		// variables for statements
		int *rIndices;

		// continue if no tokens
		if(tokenCount == 0)
			continue;

		/* main checking begins here */
		if(strcmp(tokens[0], "cd") == 0) {
			
			// for cd, we have to use chdir 
			// find directory, if not, go to home directory
			if(tokenCount > 2)
				printf("%s\n", "Error: Invalid number of arguments. Format: cd <dir_name>");
			else {
				int chd;
				if(tokenCount != 1)
					chd = chdir(tokens[1]);
				else
					chd = chdir(getenv("HOME"));
					
				if(chd == -1) 
					printf("%s\n", "Error: No such directory.");
			}
		}

		/* check if there are semicolons */
		else if((rIndices = check_statements(tokens)) != NULL) {
			for()
		}

		/* check if there are redirects */
		else if((redirectIndex = check_redirects(tokens)) != -1) {
			if(redirectIndex == tokenCount-1) {
				printf("%s\n", "Error: Invalid format.");
			}
			else {
				// initialize the firstCommand and mFile variables
				firstCommand = (char **)malloc((redirectIndex+1) * sizeof(char *));
				mFile = (char *)malloc(strlen(tokens[redirectIndex+1]) * sizeof(char));
				
				// copy filename and cmd
				strcpy(mFile, tokens[redirectIndex+1]);
				for(int i=0; i<redirectIndex; i++) {
					firstCommand[i] = (char *)malloc(strlen(tokens[i]) * sizeof(char));
					strcpy(firstCommand[i], tokens[i]);
				}
				firstCommand[redirectIndex] = NULL;

				// fork a new process and change its fd
				int pid = fork();
				if(pid == 0) {
					int fd = open(mFile, O_RDWR | O_TRUNC | O_CREAT, S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IWGRP|S_IXGRP|S_IROTH|S_IWOTH|S_IXOTH);
					if(fd < 0) {
						printf("%s\n", "Error: Cannot write to file.");
					}
					else {
						if(dup2(fd, 1) < 0){
							printf("%s\n", "Some error.");
						}
						else {
							execvp(firstCommand[0], firstCommand);
							close(fd);
						}
						return 0;
					}
				}
				else {
					int st = wait(&pid);
				}

			}
		}

		/* consider all the other functions which can be Linux system commands */
		else {
			// pass it to bash
			int pid = fork();
			if(pid == 0) {
				execvp(tokens[0], tokens);
				return 0;
			}
			else {
				int st = wait(&pid);
			}
		}
	}
	return 0;
}




