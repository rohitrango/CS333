#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* check if there are redirects of the form ``{cmd} > {filename}'' */
int check_redirects(char **tokens) {
	
	int index = -1;
	for(int i = 0; tokens[i]!=NULL; i++)
		if(strcmp(tokens[i], ">") == 0)
			index = i;

	return index;
}

/* to check if there are multiple statements */
int* check_statements(char **tokens) {
	
	int count = 0;
	for(int i = 0; tokens[i]!=NULL; i++)
		if(strcmp(tokens[i], ";;") == 0)
			count++;

	if(count == 0)
		return NULL;

	int *index = (int *)malloc((count+1) * sizeof(int));
	int t = 0;
	for(int i = 0; tokens[i]!=NULL; i++)
		if(strcmp(tokens[i], ";;") == 0) {
			index[t] = i;
			t++;
		}
	index[count+1] = NULL;
	return index;
}